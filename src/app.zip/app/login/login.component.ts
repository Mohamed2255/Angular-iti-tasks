import { Component, OnInit } from '@angular/core';
import { Login } from '../Shared Classes/Types';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor() { }
  usermodel:Login=new Login("","");
  ngOnInit(): void {
  }

}
