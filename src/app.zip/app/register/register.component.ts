import { Component, OnInit } from '@angular/core';
import { Register } from '../Shared Classes/Types';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  constructor() { }
socail=["Facbook","Twitter","google"];
usermodel:Register=new Register("","","","");
  ngOnInit(): void {
  }

}
