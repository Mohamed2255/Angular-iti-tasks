import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-withdiscount',
  templateUrl: './products-withdiscount.component.html',
  styleUrls: ['./products-withdiscount.component.scss']
})
export class ProductsWithdiscountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
