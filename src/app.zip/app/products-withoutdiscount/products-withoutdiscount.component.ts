import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-withoutdiscount',
  templateUrl: './products-withoutdiscount.component.html',
  styleUrls: ['./products-withoutdiscount.component.scss']
})
export class ProductsWithoutdiscountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
